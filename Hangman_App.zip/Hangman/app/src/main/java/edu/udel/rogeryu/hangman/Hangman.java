package edu.udel.rogeryu.hangman;

/**
 * Created by Roger Yu on 4/13/2018.
 */
import java.util.ArrayList;
public class Hangman{
    private charList word;
    private charList output;
    private charList guessed;
    private int count;
    private int numRight;
    private int numWrong;

    public Hangman(String word){
        this.word = new charList(word);
        this.output = new charList();
        for(int i = 0; i < word.length(); ++i){
            this.output.add('_');
        }
        this.guessed = new charList();
        this.count = 0;
        this.numRight = 0;
        this.numWrong = 0;
    }

    public Hangman(){
        this.word = null;
        this.output = null;
        this.guessed = null;
        this.count = 0;
        this.numRight = 0;
        this.numWrong = 0;
    }

    public charList getWord(){
        return word;
    }

    public charList getOutput(){
        return output;
    }

    public charList getGuessed(){
        return guessed;
    }

    public ArrayList<Character> getWordList(){
        return word.getList();
    }

    public ArrayList<Character> getOutputList(){
        return output.getList();
    }

    public ArrayList<Character> getGuessedList(){
        return guessed.getList();
    }

    public int getCount(){
        return count;
    }

    public int getNumRight() {
        return numRight;
    }

    public int getNumWrong() {
        return numWrong;
    }

    public void setWord(String word){
        this.word.setList(word);
    }

    public void setOutput(String word){
        this.output.setList(word);
    }

    public void setGuessed(String word){
        this.guessed.setList(word);
    }

    public void setCount(int num){
        this.count = num;
    }

    public void setNumRight(int num) {
        this.numRight = num;
    }

    public void setNumWrong(int num) {
        this.numWrong = num;
    }

    public String hangman(){
        String hang = "\n";
        if(count > 0){
            hang = hang + " O" + "\n";
        }
        if(count > 1){
            hang = hang + "\\";
        }
        if(count > 2){
            hang = hang + "|";
        }
        if(count > 3){
            hang = hang + "/" + "\n";
        }
        if(count > 4){
            hang = hang + "/";
        }
        if(count > 5){
            hang = hang + "\\";
        }
        return hang;
    }
}

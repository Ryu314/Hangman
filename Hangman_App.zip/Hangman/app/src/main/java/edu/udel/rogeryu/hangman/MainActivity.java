package edu.udel.rogeryu.hangman;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
        public static final String player1 = "Player 1";
        public static final String player2 = "Player 2";
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            super.setTitle("Hangman");
            TextView yourVariableName = findViewById(R.id.textView2);
            yourVariableName.setMovementMethod(new ScrollingMovementMethod());
        }

        /** Called when the user taps the Send button */
       public void start(View view) {
            Intent intent = new Intent(this, DisplayMessageActivity.class);
            EditText editText = (EditText) findViewById(R.id.editText);
            EditText editText2 = (EditText) findViewById(R.id.editText2);
            String message = editText.getText().toString();
            String message2 = editText2.getText().toString();
            intent.putExtra(player1, message);
            intent.putExtra(player2, message2);
            startActivity(intent);
            // Do something in response to button
        }

    }


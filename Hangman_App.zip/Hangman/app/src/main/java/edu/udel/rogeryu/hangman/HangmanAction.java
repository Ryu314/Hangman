package edu.udel.rogeryu.hangman;

/**
 * Created by Roger Yu on 4/27/2018.
 */
import java.util.ArrayList;

import edu.udel.rogeryu.framework.Action;

public class HangmanAction implements Action<HangmanState> {
    private int player;
    private Character guess;

    public HangmanAction(int player, char guess){
        this.player = player;
        this.guess = Character.toLowerCase(guess);
    }

    public boolean isValid(HangmanState hangman){
        if(Character.isLetter(guess)){
            if(player == 1){
                if(!hangman.getHangman1().getGuessedList().contains(guess)){
                    return true;
                }
            }
            else if(player == 2){
                if(!hangman.getHangman2().getGuessedList().contains(guess)){
                    return true;
                }
            }
        }
        return false;
    }

    public void update(HangmanState hangman){
        if(hangman.getTurn() == 1){
            if(hangman.getHangman2().getWordList().contains(guess)){
                ArrayList<Character> output = hangman.getHangman2().getOutputList();
                ArrayList<Character> word = hangman.getHangman2().getWordList();
                int i = 0;
                int j = 0;
                while(i < output.size()){
                    if(word.get(i) == guess){
                        output.set(i, guess);
                        i++;
                    }
                }
                charList newOutput = new charList(output.toString());
                hangman.getHangman2().setOutput(newOutput.toString());
                while(j < word.size()){
                    if(word.get(j) == guess){
                        word.set(j, '_');
                        j++;
                    }
                }
                charList newWord = new charList(word.toString());
                hangman.getHangman2().setWord(newWord.toString());
            }
        }
        else if(hangman.getTurn() == 2){
            if(hangman.getHangman1().getWordList().contains(guess)){
                ArrayList<Character> output = hangman.getHangman2().getOutputList();
                ArrayList<Character> word = hangman.getHangman2().getWordList();
                int i = 0;
                int j = 0;
                while(i < output.size()){
                    if(word.get(i) == guess){
                        output.set(i, guess);
                    }
                }
                charList newOutput = new charList(output.toString());
                hangman.getHangman1().setOutput(newOutput.toString());
                while(j < word.size()){
                    if(word.get(j) == guess){
                        word.set(j, '_');
                        j++;
                    }
                }
                charList newWord = new charList(word.toString());
                hangman.getHangman1().setWord(newWord.toString());
            }
        }
    }
}

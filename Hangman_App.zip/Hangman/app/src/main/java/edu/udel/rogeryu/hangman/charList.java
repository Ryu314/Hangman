package edu.udel.rogeryu.hangman;

/**
 * Created by Roger Yu on 4/27/2018.
 */
import java.util.ArrayList;
public class charList {
    private ArrayList<Character> list;
    public charList(){
        this.list = new ArrayList<Character>();
    }

    public charList(String name){
        this.list = new ArrayList<Character>();
        for(int i = 0; i < name.length(); i++){
            this.list.add(name.charAt(i));
        }
    }

    public ArrayList<Character> getList(){
        return list;
    }

    public void setList(String name){
        this.list.clear();
        for(int i = 0; i < name.length(); i++){
            this.list.add(name.charAt(i));
        }
    }

    public void add(char character){
        list.add(character);
    }

    public boolean isEmpty(){
        int i = 0;
        boolean empty = true;
        while(i < list.size()){
            if(list.get(i) != '_'){
                empty = false;
                break;
            }
        }
        return empty;
    }

    public String toString(){
        String string = "";
        int i = 0;
        while(i < list.size()){
            string += list.get(i);
            i++;
        }
        return string;
    }
}

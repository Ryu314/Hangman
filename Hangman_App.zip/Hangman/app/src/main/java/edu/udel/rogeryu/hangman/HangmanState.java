package edu.udel.rogeryu.hangman;

import edu.udel.rogeryu.framework.Game;

/**
 * Created by Roger Yu on 4/13/2018.
 */

public class HangmanState extends Game {
    private Hangman hangman1;
    private Hangman hangman2;
    private int turn;
    private int notTurn;

    public HangmanState(String word1, String word2){
        this.hangman1 = new Hangman(word1);
        this.hangman2 = new Hangman(word2);
        turn = 1;
        notTurn = 2;
    }

    public HangmanState(){
        hangman1 = null;
        hangman2 = null;
        turn = 1;
        notTurn = 2;
    }

    public Hangman getHangman1(){return hangman1;}

    public Hangman getHangman2(){return hangman2;}

    public int getTurn(){
        return turn;
    }

    public int getNotTurn(){
        return notTurn;
    }

    public void switchTurn(){
        int temp = turn;
        turn = notTurn;
        notTurn = temp;
    }

    public int getScore(){
        int score = 0;
        if(turn == 1){
            score = hangman1.getNumRight()*2 - hangman1.getNumWrong();
            if(isWinner(1)) {
                score += 10;
            }
            else if(isLoser(1)){
                score -= 6;
            }
            else{
                score += 0;
            }
        }
        else{
            score = hangman2.getNumRight()*2 -hangman2.getNumWrong();
            if(isWinner(2)){
                score += 10;
            }
            else if(isLoser(2)){
                score -= 6;
            }
            else{
                score += 0;
            }
        }
        return score;
    }

    public boolean isWinner(int num){
        if(num == 1){
            if(hangman2.getWord().isEmpty()){
                return true;
            }
        }
        else if(num == 2){
            if(hangman1.getWord().isEmpty()){
                return true;
            }
        }
        return false;
    }

    public boolean isLoser(int num){
        if(num == 1){
            if(hangman1.getCount() >= 5){
                return true;
            }
        }
        else if(num == 2){
            if(hangman2.getCount() >= 5){
                return true;
            }
        }
        return false;
    }

    public boolean isEnd(){
        return isWinner(turn) || isLoser(turn) || isWinner(notTurn) || isLoser(notTurn);
    }

    public String toString(){
        String output = getStatus();
        if(turn == 1){
            for(int i = 0; i < hangman2.getOutputList().size(); ++i){
                output = output + hangman2.getOutputList().get(i) + " ";
            }
            output = output + "\n" + "Guessed: " ;
            for(int i = 0; i < hangman1.getGuessedList().size(); ++i){
                output = output + hangman1.getGuessedList().get(i) + " ";
            }
            output = output + printHangman() + "\nScore: " + getScore();
        }
        else{
            for(int i = 0; i < hangman1.getOutputList().size(); ++i){
                output = output + hangman1.getOutputList().get(i) + " ";
            }
            output = output + "\n" + "Guessed: ";
            for(int i = 0; i < hangman2.getGuessedList().size(); ++i){
                output = output + hangman2.getGuessedList().get(i) + " ";
            }
            output = output + printHangman() + "\nScore: " + getScore();
        }
        return output;
    }

    public String getStatus(){
        String output = "";
        if(isEnd()){
            if(isWinner(1)) {
                output += "\nPlayer 1 wins!";
            }
            else if(isLoser(1)){
                output += "\nPlayer 1 loses!";
            }
            else if(isWinner(2)){
                    output += "\nPlayer 2 wins!";
            }
            else if(isLoser(2)){
                output += "\nPlayer 2 loses!";
            }
        }
        else{
            output += "It is Player " + turn + "'s turn.";
        }
        return output;
    }

    public String printHangman(){
        String hang = "";
        if(turn == 1){
            hang = hang + hangman1.hangman();
        }
        if(turn == 2){
            hang = hang + hangman2.hangman();
        }
        return hang;
    }
}

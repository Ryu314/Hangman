package edu.udel.rogeryu.hangman;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import edu.udel.rogeryu.framework.GameListener;

public class DisplayMessageActivity extends AppCompatActivity {
    private HangmanState game;
    private TextView guessed1;
    private TextView guessed2;
    private TextView output1;
    private TextView output2;
    private EditText input1;
    private EditText input2;
    private String word1;
    private String word2;
    public static final String wordA = "word1";
    public static final String wordB = "word2";
    public static final String change = "change";
    public static final String guessedA = "guessed1";
    public static final String guessedB = "guessed2";
    public static final String outputA = "output1";
    public static final String outputB = "output2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.player1);
        String message2 = intent.getStringExtra(MainActivity.player2);
        startGame(message, message2);
        guessed1 = findViewById(R.id.textView);
        guessed2 = findViewById(R.id.textView4);
        output1 = findViewById(R.id.textView3);
        output2 = findViewById(R.id.textView5);
        word1 = game.getHangman1().getWord().toString();
        word2 = game.getHangman2().getWord().toString();
        setText(guessed1, guessed2, output1, output2);
        TextView print = findViewById(R.id.textView11);
        print.setText(game.toString());
    }

    public HangmanState getHangmanGame(){return game;}

    public void startGame(String message, String message2){
        game = new HangmanState(message, message2);
        if(Math.random() > 0.5){
            game.switchTurn();
        }
        game.start();
    }

    public void updateGame(){
        if(this.game.getTurn() == 1){
            char input = input1.getText().toString().charAt(0);
            HangmanAction update = new HangmanAction(this.game.getTurn(), input);
            update.update(game);
        }
        else{
            char input = input2.getText().toString().charAt(0);
            HangmanAction update = new HangmanAction(this.game.getTurn(), input);
        }
        setText(this.guessed1, this.guessed2, this.output1, this.output2);
    }

    public void setText(TextView guessed1, TextView guessed2, TextView output1, TextView output2){
        guessed1.setText(game.getHangman1().getGuessed().toString());
        guessed2.setText(game.getHangman2().getGuessed().toString());
        output1.setText(game.getHangman2().getOutput().toString());
        output2.setText(game.getHangman1().getOutput().toString());
    }

    public void changePlayer(View view){
        updateGame();
        Intent intent = new Intent(this, DisplayMessageActivity2.class);
        EditText editText = (EditText) findViewById(R.id.editText3);
        char info = editText.getText().toString().charAt(0);
        intent.putExtra(change, info);
        intent.putExtra(guessedA, game.getHangman1().getGuessed().toString());
        intent.putExtra(guessedB, game.getHangman2().getGuessed().toString());
        intent.putExtra(outputA, game.getHangman2().getOutput().toString());
        intent.putExtra(outputB, game.getHangman1().getOutput().toString());
        intent.putExtra(wordA, game.getHangman1().getWord().toString());
        intent.putExtra(wordB, game.getHangman2().getWord().toString());
        startActivity(intent);
    }
}
